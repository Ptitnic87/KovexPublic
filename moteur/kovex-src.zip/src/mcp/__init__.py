"""Le serveur MCP de Kovex : des réponses calculées, en lecture seule."""
