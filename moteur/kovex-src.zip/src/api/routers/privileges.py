# Fichier : src/api/routers/privileges.py
"""Ce que le marqueur de comptes à privilèges marque, ici et maintenant.

Une seule route, et elle ne décide rien : elle dit ce que la déclaration du
workspace produit sur les données chargées. C'est le pendant de « les mots du
modèle, les chiffres du calcul » pour une liste que le client a pu écrire
lui-même — un fragment qui marque la moitié du référentiel se dénonce par son
nombre, et aucune phrase d'avertissement ne ferait ce travail aussi bien.

Le dénombrement est **recalculé à chaque appel** plutôt que conservé : un
identifiant renommé, une colonne disparue d'un export, une déclaration
modifiée dans l'écran voisin — tout cela change le résultat, et un chiffre mis
en cache dirait le contraire de ce que le produit applique.
"""

from typing import Any, Dict

from fastapi import APIRouter, Depends

from src.api.dependencies import get_data_loader
from src.core.data.loader import DataLoader
from src.core.knowledge.privileges import denombrer

router = APIRouter(prefix="/privileges", tags=["Comptes à privilèges"])


@router.get("")
def denombrement(loader: DataLoader = Depends(get_data_loader)
                 ) -> Dict[str, Any]:
    """Ce que la déclaration marquerait, fragment par fragment.

    Rendu même quand rien n'est déclaré : `declare` vaut alors `false`, et
    l'écran dit qu'aucun compte n'est marqué parce que rien n'a été demandé.
    C'est une phrase différente de « aucun compte marqué », et les confondre
    laisserait croire à un référentiel sans compte d'administration.

    Aucune identité ne sort d'ici au-delà de l'échantillon, qui porte les
    valeurs de la colonne déclarée — celles-là mêmes que l'utilisateur lit
    déjà dans l'écran des identités. Le reste est du dénombrement.
    """
    resume = denombrer(loader.identities, loader.config.privileges,
                       DataLoader.COL_USER_ID)
    # La déclaration illisible se signale comme les autres du produit : la
    # lecture s'est poursuivie sans elle, et l'écran doit le dire plutôt que
    # de montrer un marqueur vide qui passerait pour un choix.
    resume["invalide"] = loader.config.privileges_invalide
    return resume
