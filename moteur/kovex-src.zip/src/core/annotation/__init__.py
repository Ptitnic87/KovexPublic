"""Annotation sémantique optionnelle : proposer, jamais décider."""
