"""Ce que l'interface doit garantir à ceux qui la regardent."""
